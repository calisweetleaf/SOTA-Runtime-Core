# Reddit Post: SOTA Runtime Core - Drop 2

---

**Title:** Drop 2: Open-sourced the neural routing and cross-chat memory systems. Clone, drop in, run. No sign-ups. 

---

I've just released the second drop in my open-source toolkit series. This marks the second disclosure aimed at leveling the playing field and closing the capability gap between open-source LLM development and closed-door corporate development. That gap has created artificial scarcity of innovation for the open community.

This is the second, but not last, attempt to democratize access to these capabilities and ultimately decentralize the modern compute infrastructure.

**What's in Drop 2:**

- Neural prompt routing with dynamic reasoning depth, tool gating, and multi-template prompt assembly

- Cross-session memory extraction, semantic storage, and context injection that learns facts, preferences, and patterns from conversations

- Both modules run standalone. Copy and paste into your codebase. Minimal work and you now have industry standard innovations, for free.

All research was gathered through open-source data, open publications, and discussions. No proprietary innovations were accessed. This entire repository, just as RLHF, uses the Sovereign Anti-Exploitation License.

---

**Why I'm doing this:**

The infrastructure for modern AI is being hoarded. The same companies that trained on the open web now gate access to the runtime systems that make their models useful. I'm not building novel research - I'm implementing what's already documented but locked behind API paywalls and enterprise pricing.

This is practical decentralization. SOTA-tier runtime tooling, local-first, for everyone.

---

**Links:**

GitHub: https://github.com/calisweetleaf/SOTA-Runtime-Core

Zenodo: https://doi.org/10.5281/zenodo.18530654

Prior Work (Drop 1 - RLHF): https://github.com/calisweetleaf/Reinforcement-Learning-Full-Pipeline

---

**Drop 3 Preview:**

The next release is what everything has been building toward. A runtime system for already fully trained transformers that enables self-guided reasoning for long-horizon agentic tasking and an effectively infinite context window. Not compression. Not RAG. Not prompt stuffing. Something different.

Entropy and GARLIC is all you need.

Keep an eye on my HuggingFace and GitHub - 10 converted local models with these capabilities are coming soon.

---

I look forward to any questions. Please engage, ask questions, and let me know if you train or build with these systems. More drops are coming. Thank you for your time.
